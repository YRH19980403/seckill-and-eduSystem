CREATE TRIGGER in_gra
  BEFORE INSERT
  ON tb_grade
  FOR EACH ROW
  begin
    if (NEW.final_grade<60)
    then 
    set NEW.makeup_flag=0;
    end if;
end;

